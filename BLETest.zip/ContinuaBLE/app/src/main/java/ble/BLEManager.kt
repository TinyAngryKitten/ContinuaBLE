package ble

import data.DeviceInfo
import iso.CharacteristicUUIDs
import iso.ServiceUUID

actual object BLEManager {
    actual fun scanForDevicesWithServices(services: List<ServiceUUID>){
        
    }

    actual fun subscribeToCharacteristicsOfDevice(
        deviceInfo: DeviceInfo,
        characteristics: List<CharacteristicUUIDs>
    ) {
    }

    actual fun connectToDevice(deviceInfo: DeviceInfo) {
    }

    actual fun disconnectFromDevice(deviceInfo: DeviceInfo) {
    }

}