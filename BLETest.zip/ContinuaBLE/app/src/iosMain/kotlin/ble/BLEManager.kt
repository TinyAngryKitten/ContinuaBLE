package ble

import data.DeviceInfo
import iso.CharacteristicUUIDs
import iso.ServiceUUID
import iso.parseBLEReading
import platform.CoreBluetooth.CBUUID

actual object BLEManager {
    val controller = BluetoothController{ parseBLEReading(it)}

    actual fun scanForDevicesWithServices(services: List<ServiceUUID>) {
        if(controller.centralManager.isScanning) controller.centralManager.stopScan()

        controller.centralManager.scanForPeripheralsWithServices(
            services.map { CBUUID.UUIDWithString(it.id) },
            null)

        
    }

    actual fun subscribeToCharacteristicsOfDevice(
        deviceInfo: DeviceInfo,
        characteristics: List<CharacteristicUUIDs>
    ) {
    }

    actual fun connectToDevice(deviceInfo: DeviceInfo) {
    }

    actual fun disconnectFromDevice(deviceInfo: DeviceInfo) {
    }

}