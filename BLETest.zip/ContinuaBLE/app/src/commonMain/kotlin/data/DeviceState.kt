package data

data class DeviceState(
    val name : String
)