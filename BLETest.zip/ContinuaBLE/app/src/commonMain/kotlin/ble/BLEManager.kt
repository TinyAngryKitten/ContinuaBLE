package ble

import data.DeviceInfo
import iso.CharacteristicUUIDs
import iso.ServiceUUID

expect object BLEManager{
    fun scanForDevicesWithServices(services : List<ServiceUUID>)

    fun subscribeToCharacteristicsOfDevice(deviceInfo: DeviceInfo, characteristics : List<CharacteristicUUIDs>)

    fun connectToDevice(deviceInfo: DeviceInfo)
    fun disconnectFromDevice(deviceInfo: DeviceInfo)
}