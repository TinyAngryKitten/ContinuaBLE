package data

data class CharacteristicDescription(
    val UUID : String
    //val service : String
)